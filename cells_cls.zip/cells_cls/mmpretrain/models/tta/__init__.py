# Copyright (c) OpenMMLab. All rights reserved.
from .score_tta import AverageClsScoreTTA

__all__ = ['AverageClsScoreTTA']
