# Copyright (c) OpenMMLab. All rights reserved.
from .ram import RAM, RAMNormal, RAMOpenset

__all__ = ['RAM', 'RAMNormal', 'RAMOpenset']
