# Copyright (c) OpenMMLab. All rights reserved.
from .retrieval_loop import RetrievalTestLoop, RetrievalValLoop

__all__ = ['RetrievalTestLoop', 'RetrievalValLoop']
