# Copyright (c) OpenMMLab. All rights reserved.
from .weight_decay_scheduler import CosineAnnealingWeightDecay

__all__ = ['CosineAnnealingWeightDecay']
